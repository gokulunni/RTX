/* The null task template file */

void null_task(void)
{
    while (1) {}
}
